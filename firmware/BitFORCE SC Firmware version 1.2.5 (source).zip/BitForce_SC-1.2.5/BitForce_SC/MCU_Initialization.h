/*
 * MCU_Initialization.h
 *
 * Created: 08/10/2012 21:47:12
 *  Author: NASSER GHOSEIRI
 * Company: Butterfly Labs
 */ 

#ifndef MCU_INITIALIZATION_H_
#define MCU_INITIALIZATION_H_


// This section pretty much depends on which MCU We're trying to initialize here

/// ************************ MCU Initialization
void 	init_mcu(void);

#endif /* MCU_INITIALIZATION_H_ */