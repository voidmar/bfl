/*
 * HighLevel_Operations.h
 *
 * Created: 10/01/2013 00:13:37
 *  Author: NASSER GHOSEIRI
 * Company: Butterfly Labs
 */ 


#ifndef HIGHLEVEL_OPERATIONS_H_
#define HIGHLEVEL_OPERATIONS_H_

// Semi-Kernel Engine
void Microkernel_Spin(void);


#endif /* HIGHLEVEL_OPERATIONS_H_ */